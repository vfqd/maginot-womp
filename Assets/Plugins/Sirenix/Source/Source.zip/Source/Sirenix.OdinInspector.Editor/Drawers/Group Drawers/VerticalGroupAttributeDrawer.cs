//-----------------------------------------------------------------------
// <copyright file="VerticalGroupAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector.Editor.Drawers
{
    using UnityEngine;

    /// <summary>
    /// Drawer for the <see cref="VerticalGroupAttribute"/>
    /// </summary>
    /// <seealso cref="VerticalGroupAttribute"/>

    public class VerticalGroupAttributeDrawer : OdinGroupDrawer<VerticalGroupAttribute>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            var property = this.Property;
            var attribute = this.Attribute;

            GUILayout.BeginVertical();

            if (attribute.PaddingTop != 0)
            {
                GUILayout.Space(attribute.PaddingTop);
            }

            for (int i = 0; i < property.Children.Count; i++)
            {
                var child = property.Children[i];
                child.Draw(child.Label);
            }

            if (attribute.PaddingBottom != 0)
            {
                GUILayout.Space(attribute.PaddingBottom);
            }

            GUILayout.EndVertical();
        }
    }
}
#endif