//-----------------------------------------------------------------------
// <copyright file="TableAxis.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector
{
    public enum TableAxis
    {
        X,
        Y,
    }

    public enum LabelDirection
    {
        LeftToRight,
        TopToBottom,
        BottomToTop,
    }
}